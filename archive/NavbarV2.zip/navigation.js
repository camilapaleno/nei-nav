const userBox = document.querySelector(".wdgt-user-box");
const userBtn = document.querySelector(".wdgt-login");

function toggleUserBox() {
    if (userBox.style.display === "block") {
        userBox.style.display = "none";
    }
    else {
        userBox.style.display = "block";
    }
}
userBtn.addEventListener("click", toggleUserBox);




const menu = document.querySelector(".nav");
const hamburger = document.querySelector(".hamburger");

function toggleMenu() {
    if (menu.style.display === "block") {
        menu.style.display = "none";
    }
    else {
        menu.style.display = "block";
    }
}
hamburger.addEventListener("click", toggleMenu);